<?php
/***************************************************************************
*
*	Walleto - copyright (c) - sitemile.com
*	The best wordpress premium theme for having a marketplace. Sell and buy all kind of products, including downloadable goods. 
*	Have a niche marketplace website in minutes. Turn-key solution.
*
*	Coder: Andrei Dragos Saioc
*	Email: sitemile[at]sitemile.com | andreisaioc[at]gmail.com
*	More info about the theme here: http://sitemile.com/products/walleto-wordpress-marketplace-theme/
*	since v1.0.1
*
*	Dedicated to my wife: Alexandra
*
***************************************************************************/



global $query_string;
	
$closed = array(
		'key' => 'closed',
		'value' => "0",
		//'type' => 'numeric',
		'compare' => '='
);

//meta_key=keyname&orderby=meta_value&order=ASC
	
$prs_string_qu = wp_parse_args($query_string);
$prs_string_qu['meta_query'] = array($closed);
$prs_string_qu['meta_key'] = 'featured';
$prs_string_qu['orderby'] = 'meta_value';
$prs_string_qu['order'] = 'DESC';
		
query_posts($prs_string_qu);

$term = get_term_by( 'slug', get_query_var( 'term' ), get_query_var( 'taxonomy' ) );
$term_title = $term->name;
			
//======================================================

	get_header();
	?>
	 <!--left side bare end-->
      <!--middle bottom right section start-->
       <section id="middle_top_right_wrapper_category_page">
		 <!--hot products start-->
          <section id="hot_products">
              <div class="featured_product_heading">Hot Products</div>     
            <div class="hot-products-inner">
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elitsociis </p>
            <img src="<?php bloginfo('template_directory'); ?>/img/hot_products.jpg" class="img-responsive hot_product_img">
            <a href="javascript:void(0);" class="check_it_out">Check it Out</a>
            <div class="hot_products_bullets">
            	<a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
            </div>
            </div>   
          </section>
          <!--hot products end-->
            <!--featured products start-->
          <section id="featured_products">
              <div class="featured_product_heading">Featured Products</div>     
            <ul class="list-unstyled featured_product_listing featured_product_listing-right-category">
               <?php dynamic_sidebar( 'home-right-widget-area' ); ?>
             </ul>   
          </section>
          <!--featured products end-->
          <!--add banner-->
              <a href="javascrpt:void(0);" class="add_banner add-banner-right-category"><img src="<?php bloginfo('template_directory'); ?>/img/add-banner.jpg" class="img-responsive "></a>
          <!--add banner-->
          
          <!--small slider start-->
          <section id="small_slider">
          <div class="small_slider_control"><a href="javascript:void(0);" class="left_control pull-left"><i class="icon-chevron-left"></i></a> 
              <a href="javascript:void(0);" class="right_control pull-right"><i class="icon-chevron-right"></i></a></div>
              <img src="<?php bloginfo('template_directory'); ?>/img/small_slider.jpg" class="img-responsive">
          </section>
          <!--small slider end-->        
          
          </section>      
       <!--middle bottom right section end-->  
	</section>    
   
   <!--right side banner main wrapper start--> 
   <section id="right_side_banner_main_wrapper">
   <!--bread crumb start-->
    <ul class="list-unstyled" id="breadcrumb">
		<?php 
		if(function_exists('bcn_display'))
		{
		   // echo bcn_display();
		}
                ?>
   </ul>
   <!--bread crumb end-->
   <!--	<section class="cat_slider">
     <img src="<?php //bloginfo('template_directory'); ?>/img/categories_slider_img.png" alt="" class="img-responsive">
    </section>
-->
	<?php
	$Walleto_adv_code_cat_page_above_content = stripslashes(get_option('Walleto_adv_code_cat_page_above_content'));
		if(!empty($Walleto_adv_code_cat_page_above_content)):
		
			echo '<div class="full_width_a_div">';
			echo $Walleto_adv_code_cat_page_above_content;
			echo '</div>';
		endif;
	

?>

<?php 
/* comment by cis team start
		if(function_exists('bcn_display'))
		{
		    echo '<div class="my_box3 breadcrumb-wrap">';	
		    bcn_display();
			echo '</div>';
		}
		
comment end by cis
*/
?>	
<section id="wedding_products_wrapper" class="product_list_wrapper wedding_products_wrapper_class">
        <div class="product_list_heading">
	   <span class="heading_text">
	        <?php if(empty($term_title)) echo __("All Posted Products",'Walleto');
                else { echo sprintf( __("Latest Posted Products in %s",'Walleto'), $term_title); } ?>
         </span>
	     <span class="view_all">
                    <a href="#" class="view_all_items">View all Items   <i class="icon-double-angle-right ml10"></i></a>
                </span>
        </div>                        
                    <!--    <a href="<?php// bloginfo('siteurl'); ?>/?feed=rss2&<?php //echo get_query_var( 'taxonomy' ); ?>=<?php //echo get_query_var( 'term' ); ?>"><img src="<?php bloginfo('template_url'); ?>/images/rss_icon.png" 
                    border="0" width="19" height="19" alt="rss icon" /></a>-->
                        
                        <?php
						
						//}
					?> 
            		<?php
							
							echo '<div class="switchers">';
							$view = walleto_get_current_view_grid_list();
					
							if($view != "grid")
							{
								echo '<a href="'.walleto_switch_link_from_home_page('grid').'" class="grid"></a>';
								echo '<a href="'.walleto_switch_link_from_home_page('list').'" class="list-selected"></a>';
							}
							else
							{
								echo '<a href="'.walleto_switch_link_from_home_page('grid').'" class="grid-selected"></a>';
								echo '<a href="'.walleto_switch_link_from_home_page('list').'" class="list"></a>';
							}
							echo '</div>';
					
					?>
            		 
            		
		<ul class="list-unstyled product_listing_ul product_lising_four_products"> 
		<?php if ( have_posts() ): while ( have_posts() ) : the_post(); ?>
		<?php 
				if($view != "grid")
					 walleto_get_post_list_view();
				 else
					Walleto_get_post();
		 ?>
		<?php  
				endwhile; 
			?>
		</ul>
	<?php 
		if(function_exists('wp_pagenavi')):
		wp_pagenavi(); endif;
		                             
     	else:
		
		echo __('No items posted.',"Walleto");
		
		endif;
		// Reset Post Data
		wp_reset_postdata();
		 
		?>
</section>
   <!--right side banner main wrapper start-->   
  </section>
   <!--middle content top section end-->  

    <!--payment method and social icons wrapper-->
    <section id="payment_social_contact_main_wrapper" class="outer_width">
    <section class="inner_width">
      <!--payment methods wrapper-->
      <article id="paymetn_methods_wrapper">
      <p>All major payment methods accepted:</p>
		<ul class="listing_of_payments_icon list-unstyled">
            <li><a href="javascript:void(0);"><img src="<?php bloginfo('template_directory'); ?>/img/visa_button.jpg"></a></li>
            <li><a href="javascript:void(0);"><img src="<?php bloginfo('template_directory'); ?>/img/american_express.jpg"></a></li>
            <li><a href="javascript:void(0);"><img src="<?php bloginfo('template_directory'); ?>/img/mestro_card.jpg"></a></li>
            <li><a href="javascript:void(0);"><img src="<?php bloginfo('template_directory'); ?>/img/google_wishlist.jpg"></a></li>
            <li><a href="javascript:void(0);"><img src="<?php bloginfo('template_directory'); ?>/img/mastro_card_yellow.jpg"></a></li>
            <li><a href="javascript:void(0);"><img src="<?php bloginfo('template_directory'); ?>/img/paypal.jpg"></a></li>
		</ul>
      </article>
     <!--payment methods wrapper-->
    <!--social media wrapper-->
      <article id="social_media_wrapper">
      <p>Get in touch with Social Media</p>
		<ul class="social_media_list list-unstyled">
        	<li><a class="fb" href="javascript:void(0);"><i class="icon-facebook"></i></a></li>
            <li><a class="in" href="javascript:void(0);"><i class="icon-linkedin "></i></a></li>
            <li><a class="twt" href="javascript:void(0);"><i class="icon-twitter"></i></a></li>
            <li><a class="yt" href="javascript:void(0);"><i class="icon-youtube "></i></a></li>
		</ul>
      </article>
     <!--social media wrapper-->
     <div class="clearfix"></div>
    
    </section>
    </section>
    <!--payment method and social icons wrapper end-->    
  </section>
  <!--middel section end-->  

<div id="right-sidebar">
    <ul class="xoxo">
        <?php dynamic_sidebar( 'other-page-area' ); ?>
    </ul>
</div>
<?php

	get_footer();

?>
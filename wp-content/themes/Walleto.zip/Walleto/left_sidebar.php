<!--middle bottom right section start-->
       <section id="middle_top_right_wrapper_category_page">
         
         <!--hot products start-->
          <section id="hot_products">
              <div class="featured_product_heading">Hot Products</div>     
            <div class="hot-products-inner">
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elitsociis </p>
            <img src="<?php bloginfo('template_directory'); ?>/img/hot_products.jpg" class="img-responsive hot_product_img">
            <a href="javascript:void(0);" class="check_it_out">Check it Out</a>
            <div class="hot_products_bullets">
            	<a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
            </div>
            </div>   
          </section>
          <!--hot products end-->
          
          <!--featured products start-->
          <section id="featured_products">
              <div class="featured_product_heading">Featured Products</div>     
            <ul class="list-unstyled featured_product_listing featured_product_listing-right-category">
               <?php dynamic_sidebar( 'home-right-widget-area' ); ?>
             </ul>   
          </section>
          <!--featured products end-->
          <!--add banner-->
	    <a href="javascrpt:void(0);" class="add_banner add-banner-right-category"><img src="<?php bloginfo('template_directory'); ?>/img/add-banner.jpg" class="img-responsive "></a>
          <!--add banner-->
          
          <!--small slider start-->
          <section id="small_slider">
          <div class="small_slider_control"><a href="javascript:void(0);" class="left_control pull-left"><i class="icon-chevron-left"></i></a> 
              <a href="javascript:void(0);" class="right_control pull-right"><i class="icon-chevron-right"></i></a></div>
              <img src="<?php bloginfo('template_directory'); ?>/img/small_slider.jpg" class="img-responsive">
          </section>
          <!--small slider end-->        
          
          </section>      
       <!--middle bottom right section end-->  
	</section>    
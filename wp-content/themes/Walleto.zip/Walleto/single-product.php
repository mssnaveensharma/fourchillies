<?php
/***************************************************************************
*
*	Walleto - copyright (c) - sitemile.com
*	The best wordpress premium theme for having a marketplace. Sell and buy all kind of products, including downloadable goods. 
*	Have a niche marketplace website in minutes. Turn-key solution.
*
*	Coder: Andrei Dragos Saioc
*	Email: sitemile[at]sitemile.com | andreisaioc[at]gmail.com
*	More info about the theme here: http://sitemile.com/products/walleto-wordpress-marketplace-theme/
*	since v1.0.1
*
*	Dedicated to my wife: Alexandra
*
***************************************************************************/

	function walleto_colorbox_stuff()
	{	
	
		echo '<link media="screen" type="text/css" rel="stylesheet" href="'.get_bloginfo('template_url').'/css/colorbox.css" />';
		/*echo '<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.6.1/jquery.min.js"></script>'; */
		echo '<script src="'.get_bloginfo('template_url').'/js/jquery.colorbox.js" type="text/javascript"></script>';
		
		?>
        
        <script>
		
			$(document).ready(function(){

				$("a[rel='image_gal1']").colorbox();

			});
			
		</script>

        
        <?php
	}
	
	//----------------------------------------------------
	add_action('wp_head','walleto_colorbox_stuff');	
	get_header(); ?>




	<!--left side bare end-->
	<!--middle bottom right section start-->
	<section id="middle_top_right_wrapper_category_page">
         
         <!--hot products start-->
          <section id="hot_products">
		<div class="featured_product_heading">Hot Products</div>     
            <div class="hot-products-inner">
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elitsociis </p>
            <img src="<?php bloginfo('template_directory'); ?>/img/hot_products.jpg" class="img-responsive hot_product_img">
            <a href="javascript:void(0);" class="check_it_out">Check it Out</a>
            <div class="hot_products_bullets">
            	<a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
            </div>
            </div>   
          </section>
          <!--hot products end-->
          
          <!--featured products start-->
          <section id="featured_products">
              <div class="featured_product_heading">Featured Products</div>     
            <ul class="list-unstyled featured_product_listing featured_product_listing-right-category">
               <?php dynamic_sidebar( 'home-right-widget-area' ); ?>
             </ul>   
          </section>
          <!--featured products end-->
          <!--add banner-->
              <a href="javascrpt:void(0);" class="add_banner add-banner-right-category"><img src="<?php bloginfo('template_directory'); ?>/img/add-banner.jpg" class="img-responsive "></a>
          <!--add banner-->
          
          <!--small slider start-->
          <section id="small_slider">
          <div class="small_slider_control"><a href="javascript:void(0);" class="left_control pull-left"><i class="icon-chevron-left"></i></a> 
              <a href="javascript:void(0);" class="right_control pull-right"><i class="icon-chevron-right"></i></a></div>
              <img src="<?php bloginfo('template_directory'); ?>/img/small_slider.jpg" class="img-responsive">
          </section>
          <!--small slider end-->        
          
          </section>      
       <!--middle bottom right section end-->  
	</section>
   
<?php
if ( have_posts() ){ while ( have_posts() ) : the_post(); 
global $post;
		
		
	$views    	= get_post_meta(get_the_ID(), "views", true);
	if(empty($views)) $views = 0;
	$views 		= $views + 1;
	
	if(!walleto_is_owner_of_post())
	update_post_meta(get_the_ID(), "views", $views);
		
?>   
   <!--right side banner main wrapper start--> 
	<section id="right_side_banner_main_wrapper" >


		<ul class="list-unstyled" id="breadcrumb">
		<?php 
		if(function_exists('bcn_display'))
		{
		    echo bcn_display();
		}
                ?>
		</ul>
	
	<!--products view start-->
	<section id="products_view_wrapper" class="outer_width clearfix">
		<h4 class="product_view_title"><?php the_title(); ?></h4>
            	
                <div class="product_view_inner">
		<!--product view inner Left wrapper -->
		<div class="product_view_inner_left">
    			
                <div class="main_product_img_show">
                <?php echo walleto_get_first_post_image(get_the_ID(), 350, 200, 'img_class', 'image-single-product-page'); ?>
                </div>
                <div class="thumb_product_img_show">
            	
                <?php
				
				$arr = walleto_get_post_images(get_the_ID(), 4);

				if($arr)
				{
					
				foreach($arr as $image)
				{
					echo '<a class="img-responsive" href="'.walleto_wp_get_attachment_image($image, array(900, 700)).'" rel="image_gal1">'.wp_get_attachment_image( $image, array(80, 80) ).'</a>';
				}
				
				
				
				}
				//else { echo __('No images.') ;}
				
				?>
		</div>
                <!--<a href="javascript:void(0);" class="all-social-plugin"><img src="img/all_social_plugin.png" class="img-responsive"></a>-->
               
                </div>
		
		<div class="product_view_inner_right">
                <div class="title_product_view_right_side">
		<?php 
	$pr = get_post_meta(get_the_ID(),'price',true);
	$pr = walleto_get_show_price($pr);
	
	echo sprintf(__('Price: %s','Walleto'), $pr); ?>
	</div>
            <div class="description_product_view_right_side">
            <div class="title_description"><?php _e('Product Description','Walleto'); ?></div>
            <p> <?php the_content(); ?></p>            
		</div> 
                    
            <ul class="list-unstyled product_other_info">
            	<li>
                	<div class="left">Shipping:</div>
                    <div class="right"><strong>
		<?php $shps = trim(get_post_meta(get_the_ID(),	'shipping',true));
		if(!empty($shps))
		{
			 
			$shps = walleto_get_show_price($shps);
			echo sprintf(__('Shipping: %s','Walleto'), $shps);
		}?>
		</strong> to US via Fedex IP</div>
                </li>
                <li>
			<div class="left">Views:</div>
			<div class="right"><div class="color_coded"><?php echo sprintf(__('This product has been viewed %s times.','Walleto'), $views); ?></div></div>
                </li>
                <li>
                <div class="left">Social:</div>
                    <div class="right"><!-- AddThis Button BEGIN -->
			<div class="addthis_toolbox addthis_default_style ">
			<a class="addthis_button_preferred_1"></a>
			<a class="addthis_button_preferred_2"></a>
			<a class="addthis_button_preferred_3"></a>
			<a class="addthis_button_preferred_4"></a>
			<a class="addthis_button_compact"></a>
			<a class="addthis_counter addthis_bubble_style"></a>
			</div>
			<script type="text/javascript">var addthis_config = {"data_track_addressbar":true};</script>
			<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=andreisaioc"></script>
			<!-- AddThis Button END -->
		    </div>
                </li>
                <li>
                	<div class="left">Quantity:</div>
                <div class="right"><p class="piece_text"><input class="small_inpt" type="text" name="" value="<?php 
		$quant = get_post_meta(get_the_ID(),'quant',true);
		echo  $quant; ?>"> <span>piece</span></p></div>
                </li>
                <li>
                	<div class="left">Total Price:</div>
                    <div class="right">Depends on the product properties you select</div>
                </li>
            </ul>
            <div class="payment_method_button">
		<?php 
								
				if(is_user_logged_in())
				{
					global $current_user;
					get_currentuserinfo();
					$uid = $current_user->ID;
					
					$walleto_check_if_pid_is_in_watchlist = walleto_check_if_pid_is_in_watchlist(get_the_ID(), $uid);
					
					if($walleto_check_if_pid_is_in_watchlist == true)  
					$isIn_watchlist = 1;
					else 	
					 $isIn_watchlist = 0;
					 
				}
				else
				{
					$isIn_watchlist = 0;

				}
				
				if($isIn_watchlist == 1):				
				?>
                
                <a class="rem-to-watchlist" rel="<?php the_ID(); ?>" 
                href="#"><?php _e('Remove from watchlist','AuctionTheme'); ?></a>
                
                <?php else: ?>
                
                <a class="add-to-watchlist watch_list_green" rel="<?php the_ID(); ?>" 
                href="#"><i class="icon-camera"></i><?php _e('Add to watchlist','AuctionTheme'); ?></a>
                <?php endif; ?> 
		<?php
			
				if($quant > 0):
			
		?>
		<a href="<?php bloginfo('siteurl') ?>/?w_action=add_to_cart&add_to_cart=<?php the_ID(); ?>" class="add_to_cart add_to_cart_orange">
		<i class="icon-shopping-cart"></i><?php _e('Add To Cart','Walleto'); ?></a>
		<?php else: ?>
            
		<span class="error_quant"><?php _e('Unavailable product. Quantity is 0.','Walleto'); ?></span>
            
		<?php endif; ?>
           
           
            </div>
        </div>        
	<!--product view inner Right wrapper end-->        
	</div>
	<!--product view inner wrapper end-->    
	</section>
	<!--Products view end-->
	<section id="products_view_wrapper" class="outer_width clearfix">
		<div class="product_list_heading">
		<span class="heading_text"><?php _e('About Shop','Walleto'); ?></span></div>
   
    
		<?php
				
				$uid = $post->post_author;
				$shop_id = walleto_get_shop_id($uid);
				$shop_post = get_post($shop_id);
				
				echo '<div class="shop_details_single">';
				echo '<a href="'.get_permalink($shop_id).'">'.$shop_post->post_title.'</a>';
				echo '</div>';
				
				
				echo '<div class="shop_details_single shop_cnt_cnt">';
				echo  $shop_post->post_content;
				echo '</div>';
				
		?>
        
                <div class="thumbs">
        
        	<?php

				$args = array(
				'order'          => 'ASC',
				'orderby'        => 'post_date',
				'post_type'      => 'attachment',
				'meta_key' 			=> 'is_portfolio',
				'meta_value' 		=> '1',
				'post_mime_type' 	=> 'image',
				'numberposts'    	=> 6,
				'post_parent'    	=> $shop_id,
				); $i = 0;
				
				$attachments = get_posts($args);
		
		
		
			if ($attachments) {
				foreach ($attachments as $attachment) {
				$url = wp_get_attachment_url($attachment->ID);
				
					echo '<div class="div_div1"  id="image_ss'.$attachment->ID.'"><img width="50" class="image_class" height="50" src="' .
					walleto_generate_thumb($attachment->ID, 50, 50). '" />					</div>';
			  
			}
			}
		
		
			?>
        
                </div>
        
        
		<div class="shop_link_me">
        	<a href="<?php echo get_permalink($shop_id); ?>" class="explore_shop"><?php _e('Explore this Shop','Walleto'); ?></a>       
		</div>
	
		<br/>
		<div class="product_list_heading">
			<span class="heading_text"><?php _e('About Shop Owner','Walleto'); ?></span></div>
	   
		<?php
			
				echo get_user_meta($post->post_author, 'personal_info',true);
			
		?>
	</section>
	<section id="wedding_products_wrapper" class="product_list_wrapper wedding_products_wrapper_class">
	   
	<?php include 'popular-products.php'; ?>

	</section>
  </section>
   <!--right side banner main wrapper start-->   
  </section>
   <!--middle content top section end-->  	
<?php
endwhile; }
get_footer(); ?>
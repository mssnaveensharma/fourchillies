$(document).ready(function(){
		
		$('#slider2').bxSlider({
		auto: true,
		speed: 1000,
		pause: 5000,
		autoControls: false,
		displaySlideQty: 5,
		moveSlideQty: 1
	  	
		});


});

	



<?php
/***************************************************************************
*
*	Walleto - copyright (c) - sitemile.com
*	The best wordpress premium theme for having a marketplace. Sell and buy all kind of products, including downloadable goods. 
*	Have a niche marketplace website in minutes. Turn-key solution.
*
*	Coder: Andrei Dragos Saioc
*	Email: sitemile[at]sitemile.com | andreisaioc[at]gmail.com
*	More info about the theme here: http://sitemile.com/products/walleto-wordpress-marketplace-theme/
*	since v1.0.1
*
*	Dedicated to my wife: Alexandra
*
***************************************************************************/
get_header();?>
	

   </section>
   <!--right side banner main wrapper start--> 
   <section id="right_side_banner_main_wrapper">
     <!--right side slider start-->
    <figure id="right-top-slider">
      <img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/img/right_side_banner_img.jpg">
        <figcaption class="slider_content bdr-r-4">
            <div class="upto-text">Upto</div>
            <div><span class="fourty_two_percent">42%</span> <span class="off_text">off</span></div>
            <div><span class="on_text">on</span> <span class="women_collection">Women Collection</span></div>
        </figcaption>       
        <div class="controls">
        	<a href="javascript:void(0);"></a>
            <a href="javascript:void(0);"></a>
            <a href="javascript:void(0);"></a>
            <a class="active" href="javascript:void(0);"></a>
            <a href="javascript:void(0);"></a>
	</div> 
	</figure>
	<!--right side slider end-->
	<!--right side small banner start-->
	<figure id="right-small-banner">
	<img class="img-responsive" src="<?php bloginfo('template_directory'); ?>/img/small_banner.jpg">
	</figure>
	<!--right side small banner startend-->
	</section>
	<!--right side banner main wrapper start-->   
	</section>

	<section class="outer_width" id="testimonails_wrapper">
	 <?php if ( is_active_sidebar( 'main-stretch-area' ) ) : ?><?php dynamic_sidebar( 'Walleto - Stretch Wide MainPage Sidebar', 'Walleto' ); ?><?php endif; ?>
	</section>
	
	<section id="middle_bottom_section_wrapper" class="outer_width">
	<section class="inner_width">
	<!--middle bottom left section start-->
	<section id="middle_bottom_left_wrapper">
        <!--popular products start-->
        <section id="popular_products_wrapper" class="product_list_wrapper">
        	<?php include 'popular-products.php'; ?>
        </section>
        <!--popular products end-->
	<!--new  products start-->
        <section id="new_products_wrapper" class="product_list_wrapper">
        	
	<?php include 'latest-posted-products.php'; ?>
        	
	</section>
        <!--new products end-->
	<!--small banner in middle bottom left-->
        <div class="banner_small_middle_bottom">
        	<img src="<?php bloginfo('template_directory'); ?>/img/banner_bottom_middle.jpg" class="img-responsive">
        </div>
        <!--small banner in middle bottom left-->           
        </section>      
	<!--middle bottom left section end-->    
   
	 
    <!--middle bottom right section start-->
	<section id="middle_bottom_right_wrapper">
        <!--featured products start-->
        <section id="featured_products">
        <div class="featured_product_heading">Featured Products</div>     
          <ul class="list-unstyled featured_product_listing">
             <?php dynamic_sidebar( 'home-right-widget-area' ); ?>
          </ul>   
        </section>
        <!--featured products end-->
        <!--add banner-->
        <a href="javascrpt:void(0);" class="add_banner"><img src="<?php bloginfo('template_directory'); ?>/img/add-banner.jpg" class="img-responsive "></a>
        <a href="javascrpt:void(0);" class="add_banner"><img src="<?php bloginfo('template_directory'); ?>/img/add-banner.jpg" class="img-responsive "></a>
        <!--add banner-->
        
        <!--small slider start-->
        <section id="small_slider">
        <div class="small_slider_control"><a href="javascript:void(0);" class="left_control pull-left"><i class="icon-chevron-left"></i></a> 
        	<a href="javascript:void(0);" class="right_control pull-right"><i class="icon-chevron-right"></i></a></div>
        	<img src="<?php bloginfo('template_directory'); ?>/img/small_slider.jpg" class="img-responsive">
        </section>
        <!--small slider end-->        
        
        </section>      
      <!--middle bottom right section end-->           
    </section>
    </section>
    <!--middle content bottom section start--> 
    
    <!--payment method and social icons wrapper-->
    
    
    

    
   
<?php get_footer(); ?>
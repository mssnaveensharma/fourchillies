<?php
/*
Theme Name: Kinetica Sandbox | Layout Five
Version: 0.9b
Author: Michael Louviere
The template for displaying Search Results pages.
*/

?>
<?php get_header(); ?>

<!--left side bare end-->
      <!--middle bottom right section start-->
       <section id="middle_top_right_wrapper_category_page">
         
         <!--hot products start-->
          <section id="hot_products">
              <div class="featured_product_heading">Hot Products</div>     
            <div class="hot-products-inner">
            <p>Lorem ipsum dolor sit amet, consectetuer adipiscing elitsociis </p>
            <img src="<?php bloginfo('template_directory'); ?>/img/hot_products.jpg" class="img-responsive hot_product_img">
            <a href="javascript:void(0);" class="check_it_out">Check it Out</a>
            <div class="hot_products_bullets">
            	<a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
                <a href="javascript:void(0);"> </a>
            </div>
            </div>   
          </section>
          <!--hot products end-->
          
          <!--featured products start-->
          <section id="featured_products">
              <div class="featured_product_heading">Featured Products</div>     
            <ul class="list-unstyled featured_product_listing featured_product_listing-right-category">
               <?php dynamic_sidebar( 'home-right-widget-area' ); ?>
             </ul>   
          </section>
          <!--featured products end-->
          <!--add banner-->
              <a href="javascrpt:void(0);" class="add_banner add-banner-right-category"><img src="<?php bloginfo('template_directory'); ?>/img/add-banner.jpg" class="img-responsive "></a>
          <!--add banner-->
          
          <!--small slider start-->
          <section id="small_slider">
          <div class="small_slider_control"><a href="javascript:void(0);" class="left_control pull-left"><i class="icon-chevron-left"></i></a> 
              <a href="javascript:void(0);" class="right_control pull-right"><i class="icon-chevron-right"></i></a></div>
              <img src="<?php bloginfo('template_directory'); ?>/img/small_slider.jpg" class="img-responsive">
          </section>
          <!--small slider end-->        
          
          </section>      
       <!--middle bottom right section end-->  
      </section>

   <section id="right_side_banner_main_wrapper">
          <section id="product_list_new" class="product_list_wrapper wedding_products_wrapper_class">
	     <div class="product_list_heading">
		 <span class="heading_text">Advanced Search</span>
		     <span class="view_all">
		     <a href="javasctipt:void(0);" class="view_all_items">View all Items   <i class="icon-double-angle-right ml10"></i></a>
		 </span>
	     </div>
	     <ul class="list-unstyled product_listing_ul all_posted_products_list">
	      <?php
	      $image_thing_tags = 'main-image-post';
	      if ( have_posts() ) : while ( have_posts() ) : the_post();
	      ?>
		<li>
		 <div class="product_block_top product_block_light_strip"></div>              
		  <div class="product_block_middle">
		    <a href="javascript:void(0);"><?php echo walleto_get_first_post_image(get_the_ID(),'','','',$image_thing_tags,1);?></a>
		    <div class="product-content">
					  <a href="javascript:void(0);" class="product_name"><?php echo substr(the_title('', '', FALSE), 0, 20);?>....</a>
		      <p class="product_detail"><?php echo substr(get_the_excerpt(), 0,30);?></p>                                      
		    </div>
			<div class="product-price">
					  <span class="product_orignal_price">$190.00</span>
		      <span class="product_discount_price">$169.90 </span>                                      
		    </div>
		    <a href="javascript:void(0);" class="buy_now_btn"><i class="icon-shopping-cart"></i> Buy Now </a>
		  </div>
		  <div class="product_block_bottom product_block_light_strip"></div>
		</li>
	        <?php endwhile;
		else : ?>
                <h1><?php _e( 'Nothing Found', 'pccti' ); ?></h1>
                <p><?php _e( 'Sorry, but nothing matched your search criteria. Please try again with some different keywords.', 'sandbox' ); ?></p>
                <div style="margin-top:10px;"><?php get_search_form(); ?></div>
                <?php endif; ?>

	     </ul>
	  </section>
</section>
<!--right side banner main wrapper start-->  

<?php get_footer(); ?>
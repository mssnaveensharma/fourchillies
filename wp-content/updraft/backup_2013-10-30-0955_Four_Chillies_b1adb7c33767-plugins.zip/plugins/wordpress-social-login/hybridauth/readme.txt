basically, we drop here the latest version of hybridauth library and that is it 

HybridAuth 
http://hybridauth.sourceforge.net
=================================

HybridAuth enables developers to easily build social applications and tools to engage websites vistors and customers on 
a social level by implementing social sign-in, social sharing, users profiles, friends list, activities stream, status 
updates and more. 

The main goal of HybridAuth is to act as an abstract API between your application and various social apis and identities 
providers such as Facebook, Twitter, MySpace and Google.

<?php

/**
 * Copyright 2012 Go Daddy Operating Company, LLC. All Rights Reserved.
 */

// Make sure it's wordpress
if ( !defined( 'ABSPATH') )
	die( 'Forbidden' );

?>

<div style="margin: 17px;">

    <div class="postbox article-7335-title">    
        <strong style="font-size: 1.17em; color: #21759B;">
            <?php _e( 'Keeping Your WordPress Site Secure', 'welcome-to-wordpress' ); ?>
        </strong>
		<div class="wtwp-article" id="article-7335"></div>
    </div>       
</div>
<?php

/**
 * Copyright 2012 Go Daddy Operating Company, LLC. All Rights Reserved.
 */

// Make sure it's wordpress
if ( !defined( 'ABSPATH') )
	die( 'Forbidden' );

?>
	</div>
	<div id="wtwp-copyright">
	<?php _e( 'Copyright', 'welcome-to-wordpress' ); ?> &copy; 2012-<?php echo date('Y'); ?>
	<?php _e( 'Starfield Technologies, LLC.', 'welcome-to-wordpress' ); ?>
	<?php _e( 'All rights reserved.', 'welcome-to-wordpress' ); ?>
</div>

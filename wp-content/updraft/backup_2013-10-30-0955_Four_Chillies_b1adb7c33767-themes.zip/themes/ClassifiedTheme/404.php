<?php
/********************************************************************************
*
*	ClassifiedTheme - copyright (c) - sitemile.com - Details
*	http://sitemile.com/p/classifiedTheme
*	Code written by_________Saioc Dragos Andrei
*	email___________________andreisaioc@gmail.com
*	since v6.2.1
*
*********************************************************************************/


	get_header();

?>

	<?php 

		if(function_exists('bcn_display'))
		{
		    echo '<div class="my_box3_breadcrumb"><div class="padd10_a">';	
		    bcn_display();
			echo '</div></div>';
		}
		
		
		
?> 


<div id="content">
    <div class="box_title"><?php _e('Page Not Found','ClassifiedTheme'); ?></div>
	<div class="padd10">
<?php _e('The requested page cannot be found. Maybe your item has not been approved yet.','ClassifiedTheme'); ?>

    </div>
    </div>


  <!-- ################### -->
    
    <div id="right-sidebar">    
    	<ul class="xoxo">
        	 <?php dynamic_sidebar( 'single-widget-area' ); ?>
        </ul>    
    </div>


<?php

	get_footer();

?>